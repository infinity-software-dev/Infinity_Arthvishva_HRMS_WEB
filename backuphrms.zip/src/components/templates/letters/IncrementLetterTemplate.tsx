import React from 'react';
import { LetterHeadLayout } from '@/components/templates/LetterHeadLayout';

export interface IncrementLetterData {
    letterNumber: string;         // e.g. "001"  -> "Infinity/Increment Letter/ 2025-2026/001"
    financialYear?: string;       // default "2025-2026"
    date: string;                 // e.g. 00/00/2026
    candidateName: string;
    effectiveMonth: string;       // e.g. "April 2026"
    joiningDate: string;
    employeeId: string;
    revisedAnnualCTC: string;
    designation: string;
    revisedTerms?: string;
}

interface IncrementLetterTemplateProps {
    data: IncrementLetterData;
    /** Optional: revised salary annexure, shown at the end of the letter */
    annexure?: React.ReactNode;
}



type Align = 'left' | 'justify' | 'center' | 'right';

/** One Word paragraph: 8pt space after; body paragraphs have a 323 twip (~21.5px) right indent. Empty = blank line. */
const P: React.FC<{ align?: Align; indent?: boolean; children?: React.ReactNode }> = ({
    align = 'justify',
    indent = true,
    children,
}) => (
    <p style={{ margin: '0 0 8pt 0', paddingRight: indent ? '21.5px' : 0, textAlign: align }}>
        {children ?? '\u00A0'}
    </p>
);

const B: React.FC<{ children: React.ReactNode }> = ({ children }) => <strong>{children}</strong>;

const Row: React.FC<{ label: string; value?: string }> = ({ label, value }) => (
    <div style={{ display: 'flex', margin: '0 0 8pt 0', paddingRight: '21.5px' }}>
        <span style={{ width: '2in', flexShrink: 0 }}>{label}</span>
        <span>- {value}</span>
    </div>
);

export const IncrementLetterTemplate: React.FC<IncrementLetterTemplateProps> = ({ data, annexure }) => {
    const fy = data.financialYear || '2025-2026';

    return (
        <LetterHeadLayout>

            <p
                style={{
                    margin: '0 0 16pt 0',
                    textAlign: 'center',
                    fontSize: '16pt',
                    fontWeight: 700,
                    color: '#2F5496',
                    textDecoration: 'underline',
                    textTransform: 'uppercase',
                }}
            >
                INCREMENT LETTER
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', margin: '0 0 8pt 0' }}>
                <span>Infinity/Increment Letter/ {fy}/{data.letterNumber}</span>
                <span>Date: {data.date}</span>
            </div>

            <P align="justify" indent={false}>Dear <B>{data.candidateName}</B></P>

            <P>
                Your salary has been hiked from the month of {data.effectiveMonth}. We thank you for being associated with the company and as a token of gratitude, we have decided to do the increment. We expect your efforts for the financial year {fy} in achieving the targets and putting efforts in executing your responsibilities.
            </P>

            <Row label="Joining Date" value={data.joiningDate} />
            <Row label="Employee ID" value={data.employeeId} />
            <Row label="Your Revised Annual CTC is" value={data.revisedAnnualCTC} />
            <Row label="Your designation is" value={data.designation} />
            <Row label="Revised Terms & conditions" value={data.revisedTerms} />

            <P>
                <B>Performance Appraisals</B> shall be based on the company, project and individual performance. Depending upon project target achievement and Department target achievement of more than 75%, increment shall be considered. Based on Performance achievement, the Increments shall be done. Yearly target and achievement shall be appraised for the projects and the departments and on the basis of it Increment policy shall be implemented.
            </P>

            <P>
                <B>Non-Compliance</B> - If during the service period if you are found guilty of any unethical practices or have done any losses of property, machinery, documents, or defame company name, manipulation of work-related activity or done financial losses or if you are engaged in other services of employment, as well as if you do not serve working notice period of <B>30 days</B> and proper handover not done, etc... or conduct any business during the service period. Then you will be liable to incur the losses, pay to company <B>30 days</B> salary, no experience letter shall be provided and management reserves the right to take legal action against you for noncompliance of the same.
            </P>

            <P>
                <B>Notice Period</B>: In case you wish to resign/ leave the services of the company, you would have to give a <B>30 days'</B> working notice period to the company and proper handover procedure. If you fail to provide such a notice period then you will not get the salary and as well as Experience and Relieving letter will not be provided without the above-mentioned notice period. And no claims or reimbursements if any shall be paid.
            </P>

            <P>Salary Annexure sheet attached for your reference.</P>

            <P>We look forward for a long-term association with your progressive career growth in the organization.</P>
            <P />

            <div className="in-avoid">
                <P>Regards,</P>
                <P />
                <P>Director</P>
                <P>Infinity Arthvishva</P>
            </div>

            {annexure && (
                <div style={{ marginTop: '4.5em' }}>
                    {annexure}
                </div>
            )}
        </LetterHeadLayout>
    );
};
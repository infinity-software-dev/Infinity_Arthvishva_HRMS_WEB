import React, { useState } from 'react';
import { FormInput, FormSelect } from '@/components/elements/FormFields';
import { IncrementLetterData } from '@/components/templates/letters/IncrementLetterTemplate';
import { useEmployees } from '@/hooks/employee-hooks/useEmployees';

interface IncrementLetterFormProps {
    onSubmit: (data: IncrementLetterData) => void;
}

export const IncrementLetterForm: React.FC<IncrementLetterFormProps> = ({ onSubmit }) => {
    const [formData, setFormData] = useState<IncrementLetterData & { employeeEmail?: string }>({
        letterNumber: '',
        financialYear: '2025-2026',
        date: '',
        candidateName: '',
        effectiveMonth: '',
        joiningDate: '',
        employeeId: '',
        revisedAnnualCTC: '',
        designation: '',
        revisedTerms: '',
        employeeEmail: '',
    });

    const { employees } = useEmployees('', '', 'Active', 1, 1000);
    const employeeOptions = [
        { label: 'Select Employee', value: '' },
        ...employees.map(emp => ({
            label: emp.name,
            value: emp.name
        }))
    ];

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;

        // Auto-fill when employee is selected
        if (name === 'candidateName') {
            const selected = value ? employees.find(emp => emp.name === value) : null;
            const joiningDate = selected?.joiningDate
                ? new Date(selected.joiningDate).toISOString().split('T')[0]
                : '';
            setFormData(prev => ({
                ...prev,
                candidateName: value,
                designation: selected?.position || '',
                employeeId: selected?.employeeCode || '',
                joiningDate: joiningDate || '',
                employeeEmail: selected?.email || '',
            }));
            return;
        }

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormInput
                    label="Letter Number"
                    name="letterNumber"
                    type="number"
                    value={formData.letterNumber || ''}
                    onChange={handleChange}
                    placeholder="e.g. 001"
                    required
                />
                <FormInput
                    label="Financial Year (Optional)"
                    name="financialYear"
                    type="text"
                    value={formData.financialYear || ''}
                    onChange={handleChange}
                    placeholder="e.g. 2025-2026"
                />
                <FormInput
                    label="Date"
                    name="date"
                    type="date"
                    value={formData.date || ''}
                    onChange={handleChange}
                    textTransform="none"
                    required
                />
                <FormSelect
                    label="Employee Name"
                    name="candidateName"
                    value={formData.candidateName || ''}
                    onChange={handleChange}
                    options={employeeOptions}
                    required
                />
                <FormInput
                    label="Effective Month"
                    name="effectiveMonth"
                    type="text"
                    value={formData.effectiveMonth || ''}
                    onChange={handleChange}
                    placeholder="e.g. April 2026"
                    required
                />
                <FormInput
                    label="Joining Date"
                    name="joiningDate"
                    type="date"
                    value={formData.joiningDate || ''}
                    onChange={handleChange}
                    textTransform="none"
                    required
                />
                <FormInput
                    label="Employee ID"
                    name="employeeId"
                    type="text"
                    value={formData.employeeId || ''}
                    onChange={handleChange}
                    required
                />
                <FormInput
                    label="Designation"
                    name="designation"
                    type="text"
                    value={formData.designation || ''}
                    onChange={handleChange}
                    required
                />
                <FormInput
                    label="Revised Annual CTC"
                    name="revisedAnnualCTC"
                    type="number"
                    value={formData.revisedAnnualCTC || ''}
                    onChange={handleChange}
                    placeholder="e.g. 600000"
                    required
                />
                <FormInput
                    label="Revised Terms & Conditions (Optional)"
                    name="revisedTerms"
                    type="text"
                    value={formData.revisedTerms || ''}
                    onChange={handleChange}
                />
            </div>

            <div className="flex justify-end pt-4">
                <button
                    type="submit"
                    className="px-6 py-2.5 bg-brand-green text-white font-medium rounded-xl hover:bg-brand-green/90 transition-all focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2 dark:focus:ring-offset-gray-900"
                >
                    Preview & Generate
                </button>
            </div>
        </form>
    );
};
